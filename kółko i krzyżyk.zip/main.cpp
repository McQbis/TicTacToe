#include <iostream>
#include <SDL2/SDL.h>
#include "game.h"

using namespace std;

int main( int argc, char* args[] )
{
	Game g;
	return 0;
}
